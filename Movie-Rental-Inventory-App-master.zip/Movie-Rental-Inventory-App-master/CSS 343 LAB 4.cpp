#include <iostream>
#include <string>
#include "HashTable.h"
#include "Movie.h"
#include "InputProccesor.h"
#include "Store.h"
#include <set>
#include <algorithm>
using namespace std;
int main()
{
	Store store;
	store.Excecute();	
    return 0;

}

