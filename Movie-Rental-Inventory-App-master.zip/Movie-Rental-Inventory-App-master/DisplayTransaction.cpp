// DisplayTransaction.cpp --------------------------------------------------------
// Shayan Raouf CSS343 Section Number
// Creation Date: 2/22/2016
// Date of Last Modification: 2/19/2016
// ----------------------------------------------------------------------------
// Purpose - Child class of Transaction and base class of InventoryTransaction
//			and HistoryTransaction
// ----------------------------------------------------------------------------
#include "DisplayTransaction.h"

// constructor ----------------------------------------------------------
// Description: 
// Precondition: NONE
// Features: 
// ----------------------------------------------------------------------
DisplayTransaction::DisplayTransaction()
{
}

// destructor ----------------------------------------------------------
// Description: 
// Precondition: NONE
// Features: 
// ----------------------------------------------------------------------
DisplayTransaction::~DisplayTransaction()
{
}

